package com.example.campushelper.ui.academicresources.scheduling;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.campushelper.R;
import com.example.campushelper.databinding.FragmentArSchedulingBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class SchedulingFragment extends Fragment implements View.OnClickListener {

    private FragmentArSchedulingBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SchedulingViewModel schedulingViewModel =
                new ViewModelProvider(this).get(SchedulingViewModel.class);

        binding = FragmentArSchedulingBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        View v = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_ar_scheduling, null);


        // Initialize buttons and set up click listeners
        Button piButton = (Button) v.findViewById(R.id.pi_button);  // program information
        piButton.setOnClickListener(this);
        Button ciButton = (Button) v.findViewById(R.id.ci_button);  // course information
        ciButton.setOnClickListener(this);
        Button gpButton = (Button) v.findViewById(R.id.gp_button);  // gradutation planner
        gpButton.setOnClickListener(this);
        Button rgButton = (Button) v.findViewById(R.id.rg_button);  // registration guides
        rgButton.setOnClickListener(this);
        Button sbButton = (Button) v.findViewById(R.id.sb_button);  // schedule builder
        sbButton.setOnClickListener(this);
        FloatingActionButton schedulingHelpButton = v.findViewById(R.id.scheduling_help_button);   // help
        schedulingHelpButton.setOnClickListener(this);

        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // Use cases to determine what to do for each click of a button
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            // Go to program information
            case R.id.pi_button:
                Intent pi = new Intent(Intent.ACTION_VIEW, Uri.parse("https://catalogs.umn.edu/twin-cities-programs"));
                startActivity(pi);
                break;
            // Go to course information
            case R.id.ci_button:
                Intent ci = new Intent(Intent.ACTION_VIEW, Uri.parse("http://classinfo.umn.edu"));
                startActivity(ci);
                break;
            // Go to graduation planner
            case R.id.gp_button:
                Intent gp = new Intent(Intent.ACTION_VIEW, Uri.parse("https://plan.umn.edu"));
                startActivity(gp);
                break;
            // Got to registration guides
            case R.id.rg_button:
                Intent rg = new Intent(Intent.ACTION_VIEW, Uri.parse("https://onestop.umn.edu/academics/classes"));
                startActivity(rg);
                break;
            // Go to Schedule Builder
            case R.id.sb_button:
                Intent sb = new Intent(Intent.ACTION_VIEW, Uri.parse("https://schedulebuilder.umn.edu"));
                startActivity(sb);
                break;
            case R.id.scheduling_help_button:
                // Create the popup window
                View popupView = LayoutInflater.from(getActivity()).inflate(
                        R.layout.fragment_ar_popup, null);

                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                boolean focusable = true; // lets taps outside the popup also dismiss it
                PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
                popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                popupWindow.setElevation(90);
                popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

                // Dismiss the popup window when screen is tapped
                popupView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        popupWindow.dismiss();
                        return true;
                    }
                });
                break;
            default:
                break;
        }
    }
}
