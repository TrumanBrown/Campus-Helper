package com.example.campushelper.ui.locationfinder;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class LfViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public LfViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is the location finder fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}