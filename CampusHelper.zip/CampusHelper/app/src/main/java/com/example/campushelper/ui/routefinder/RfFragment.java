package com.example.campushelper.ui.routefinder;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.example.campushelper.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Spinner;

public class RfFragment extends Fragment implements View.OnClickListener {

    //private FragmentLfBinding binding;
    String spinnerView = "";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
//        LfViewModel slideshowViewModel =
//                new ViewModelProvider(this).get(LfViewModel.class);
//
//        binding = FragmentLfBinding.inflate(inflater, container, false);
//        View root = binding.getRoot();
//
//        final TextView textView = binding.textLf;
//        slideshowViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
//        return root;
        // Create the popup window

        View v = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_rf, null);

        Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this.getActivity(),
                R.array.locations_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                CardView scenicC = (CardView) getView().findViewById(R.id.scenicCard);
                CardView shortC = (CardView) getView().findViewById(R.id.shortCard);
                CardView warmC = (CardView) getView().findViewById(R.id.warmCard);

                if (adapterView.getItemAtPosition(i).equals("Coffman Memorial Union")) {
                    scenicC.setVisibility(View.VISIBLE);
                    shortC.setVisibility(View.VISIBLE);
                    warmC.setVisibility(View.VISIBLE);

                    spinnerView = "Coffman Memorial Union";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

        });

        View popupView = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_rf_popup, null);

        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        popupWindow.setElevation(90);
        popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);

        // Dismiss the popup window when screen is tapped
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                popupWindow.dismiss();
                return true;
            }
        });

        Button scenicBut = (Button) v.findViewById(R.id.scenicButton);
        scenicBut.setOnClickListener(this);
        Button warmBut = (Button) v.findViewById(R.id.warmButton);
        warmBut.setOnClickListener(this);
        Button shortBut = (Button) v.findViewById(R.id.shortButton);
        shortBut.setOnClickListener(this);
        FloatingActionButton rfhelpBut = (FloatingActionButton) v.findViewById(R.id.routefinder_help_button);
        rfhelpBut.setOnClickListener(this);

        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
//        binding = null;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.scenicButton:
                CardView scenicC = (CardView) getView().findViewById(R.id.scenicCard);
                CardView shortC = (CardView) getView().findViewById(R.id.shortCard);
                CardView warmC = (CardView) getView().findViewById(R.id.warmCard);

                ImageView ir1 = (ImageView) getView().findViewById(R.id.scenic);
                ir1.setVisibility(View.VISIBLE);
                ImageView emptyr1 = (ImageView) getView().findViewById(R.id.empty);
                emptyr1.setVisibility(View.INVISIBLE);
                scenicC.setVisibility(View.INVISIBLE);
                shortC.setVisibility(View.INVISIBLE);
                warmC.setVisibility(View.INVISIBLE);

                break;

            case R.id.warmButton:
                CardView scenicC2 = (CardView) getView().findViewById(R.id.scenicCard);
                CardView shortC2 = (CardView) getView().findViewById(R.id.shortCard);
                CardView warmC2 = (CardView) getView().findViewById(R.id.warmCard);

                ImageView ir2 = (ImageView) getView().findViewById(R.id.warmest);
                ir2.setVisibility(View.VISIBLE);
                ImageView emptyr2 = (ImageView) getView().findViewById(R.id.empty);
                emptyr2.setVisibility(View.INVISIBLE);
                scenicC2.setVisibility(View.INVISIBLE);
                shortC2.setVisibility(View.INVISIBLE);
                warmC2.setVisibility(View.INVISIBLE);
                break;
            case R.id.shortButton:
                CardView scenicC3 = (CardView) getView().findViewById(R.id.scenicCard);
                CardView shortC3 = (CardView) getView().findViewById(R.id.shortCard);
                CardView warmC3 = (CardView) getView().findViewById(R.id.warmCard);

                ImageView ir3 = (ImageView) getView().findViewById(R.id.fastest);
                ir3.setVisibility(View.VISIBLE);
                ImageView emptyr3 = (ImageView) getView().findViewById(R.id.empty);
                emptyr3.setVisibility(View.INVISIBLE);
                scenicC3.setVisibility(View.INVISIBLE);
                shortC3.setVisibility(View.INVISIBLE);
                warmC3.setVisibility(View.INVISIBLE);
                break;
            case R.id.routefinder_help_button:
                // Create the popup window
                View popupView = LayoutInflater.from(getActivity()).inflate(
                        R.layout.fragment_rf_popup, null);

                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                boolean focusable = true; // lets taps outside the popup also dismiss it
                PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
                popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                popupWindow.setElevation(90);
                popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

                // Dismiss the popup window when screen is tapped
                popupView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        popupWindow.dismiss();
                        return true;
                    }
                });
                break;

            default:
                break;
        }
    }

}