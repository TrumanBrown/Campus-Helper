package com.example.campushelper.ui.locationfinder;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.campushelper.R;
import com.example.campushelper.databinding.FragmentLfBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SearchView;

public class LfFragment extends Fragment implements View.OnClickListener {

    private FragmentLfBinding binding;
    String spinnerView = "";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
//        LfViewModel slideshowViewModel =
//                new ViewModelProvider(this).get(LfViewModel.class);
//
//        binding = FragmentLfBinding.inflate(inflater, container, false);
//        View root = binding.getRoot();
//
//        final TextView textView = binding.textLf;
//        slideshowViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
//        return root;
        View v = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_lf, null);

        Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this.getActivity(),
                R.array.categories_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // Create the popup window
        View popupView = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_lf_popup, null);

        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        popupWindow.setElevation(90);
        popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            CardView cv1 = (CardView) getView().findViewById(R.id.card);
            CardView cv2 = (CardView) getView().findViewById(R.id.card2);
            CardView cv3 = (CardView) getView().findViewById(R.id.card3);
            CardView cv4 = (CardView) getView().findViewById(R.id.card4);
            CardView cv5 = (CardView) getView().findViewById(R.id.card5);
            if (adapterView.getItemAtPosition(i).equals("All Places")) {
                cv1.setVisibility(View.VISIBLE);
                cv2.setVisibility(View.VISIBLE);
                cv3.setVisibility(View.VISIBLE);
                cv4.setVisibility(View.VISIBLE);
                cv5.setVisibility(View.VISIBLE);
                spinnerView="All Places";
            }
            else if (adapterView.getItemAtPosition(i).equals("Good Views")) {
                cv1.setVisibility(View.VISIBLE);
                cv2.setVisibility(View.VISIBLE);
                cv3.setVisibility(View.VISIBLE);
                cv4.setVisibility(View.INVISIBLE);
                cv5.setVisibility(View.INVISIBLE);
                spinnerView="Good Views";
            }
            else if (adapterView.getItemAtPosition(i).equals("Useful Places")) {
                cv1.setVisibility(View.INVISIBLE);
                cv2.setVisibility(View.INVISIBLE);
                cv3.setVisibility(View.INVISIBLE);
                cv4.setVisibility(View.VISIBLE);
                cv5.setVisibility(View.INVISIBLE);
                spinnerView="Useful Places";
            }
            else if (adapterView.getItemAtPosition(i).equals("Quiet Spots")) {
                cv1.setVisibility(View.INVISIBLE);
                cv2.setVisibility(View.INVISIBLE);
                cv3.setVisibility(View.INVISIBLE);
                cv4.setVisibility(View.INVISIBLE);
                cv5.setVisibility(View.VISIBLE);
                spinnerView="Quiet Spots";
            }
            else {
                cv1.setVisibility(View.INVISIBLE);
                cv2.setVisibility(View.INVISIBLE);
                cv3.setVisibility(View.INVISIBLE);
                cv4.setVisibility(View.INVISIBLE);
                cv5.setVisibility(View.INVISIBLE);
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
        }

        });

        Button button = (Button) v.findViewById(R.id.button);
        button.setOnClickListener(this);
        Button button2 = (Button) v.findViewById(R.id.button2);
        button2.setOnClickListener(this);
        Button button3 = (Button) v.findViewById(R.id.button3);
        button3.setOnClickListener(this);
        Button button4 = (Button) v.findViewById(R.id.button4);
        button4.setOnClickListener(this);
        Button button5 = (Button) v.findViewById(R.id.button5);
        button5.setOnClickListener(this);
        FloatingActionButton lfHelpButton = v.findViewById(R.id.lf_help_button);   // help
        lfHelpButton.setOnClickListener(this);
        ImageView image1 = (ImageView) v.findViewById(R.id.WalkingBridgeImage);
        image1.setOnClickListener(this);
        ImageView image2 = (ImageView) v.findViewById(R.id.BikePathImage);
        image2.setOnClickListener(this);
        ImageView image3 = (ImageView) v.findViewById(R.id.BigFieldImage);
        image3.setOnClickListener(this);
        ImageView image4 = (ImageView) v.findViewById(R.id.WalterLibraryImage);
        image4.setOnClickListener(this);
        ImageView image5 = (ImageView) v.findViewById(R.id.BohemianFlatsImage);
        image5.setOnClickListener(this);

        // Dismiss the popup window when screen is tapped
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                popupWindow.dismiss();
                return true;
            }
        });

        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.lf_help_button:
                // Create the popup window
                View popupView = LayoutInflater.from(getActivity()).inflate(
                        R.layout.fragment_lf_popup, null);
                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                boolean focusable = true; // lets taps outside the popup also dismiss it
                PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
                popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                popupWindow.setElevation(90);
                popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

                // Dismiss the popup window when screen is tapped
                popupView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        popupWindow.dismiss();
                        return true;
                    }
                });
                break;
            case R.id.button:
                CardView cv1 = (CardView) getView().findViewById(R.id.card);
                CardView cv2 = (CardView) getView().findViewById(R.id.card2);
                CardView cv3 = (CardView) getView().findViewById(R.id.card3);
                CardView cv4 = (CardView) getView().findViewById(R.id.card4);
                CardView cv5 = (CardView) getView().findViewById(R.id.card5);
                ImageView i1 = (ImageView) getView().findViewById(R.id.WalkingBridgeImage);
                i1.setVisibility(View.VISIBLE);
                cv1.setVisibility(View.INVISIBLE);
                cv2.setVisibility(View.INVISIBLE);
                cv3.setVisibility(View.INVISIBLE);
                cv4.setVisibility(View.INVISIBLE);
                cv5.setVisibility(View.INVISIBLE);
                break;

            case R.id.button2:
                CardView cv12 = (CardView) getView().findViewById(R.id.card);
                CardView cv22 = (CardView) getView().findViewById(R.id.card2);
                CardView cv32 = (CardView) getView().findViewById(R.id.card3);
                CardView cv42 = (CardView) getView().findViewById(R.id.card4);
                CardView cv52 = (CardView) getView().findViewById(R.id.card5);
                ImageView i12 = (ImageView) getView().findViewById(R.id.BikePathImage);
                i12.setVisibility(View.VISIBLE);
                cv12.setVisibility(View.INVISIBLE);
                cv22.setVisibility(View.INVISIBLE);
                cv32.setVisibility(View.INVISIBLE);
                cv42.setVisibility(View.INVISIBLE);
                cv52.setVisibility(View.INVISIBLE);
                break;
            case R.id.button3:
                CardView cv13 = (CardView) getView().findViewById(R.id.card);
                CardView cv23 = (CardView) getView().findViewById(R.id.card2);
                CardView cv33 = (CardView) getView().findViewById(R.id.card3);
                CardView cv43 = (CardView) getView().findViewById(R.id.card4);
                CardView cv53 = (CardView) getView().findViewById(R.id.card5);
                ImageView i13 = (ImageView) getView().findViewById(R.id.BigFieldImage);
                i13.setVisibility(View.VISIBLE);
                cv13.setVisibility(View.INVISIBLE);
                cv23.setVisibility(View.INVISIBLE);
                cv33.setVisibility(View.INVISIBLE);
                cv43.setVisibility(View.INVISIBLE);
                cv53.setVisibility(View.INVISIBLE);
                break;
            case R.id.button4:
                CardView cv14 = (CardView) getView().findViewById(R.id.card);
                CardView cv24 = (CardView) getView().findViewById(R.id.card2);
                CardView cv34 = (CardView) getView().findViewById(R.id.card3);
                CardView cv44 = (CardView) getView().findViewById(R.id.card4);
                CardView cv54 = (CardView) getView().findViewById(R.id.card5);
                ImageView i14 = (ImageView) getView().findViewById(R.id.BohemianFlatsImage);
                i14.setVisibility(View.VISIBLE);
                cv14.setVisibility(View.INVISIBLE);
                cv24.setVisibility(View.INVISIBLE);
                cv34.setVisibility(View.INVISIBLE);
                cv44.setVisibility(View.INVISIBLE);
                cv54.setVisibility(View.INVISIBLE);
                break;
            case R.id.button5:
                CardView cv15 = (CardView) getView().findViewById(R.id.card);
                CardView cv25 = (CardView) getView().findViewById(R.id.card2);
                CardView cv35 = (CardView) getView().findViewById(R.id.card3);
                CardView cv45 = (CardView) getView().findViewById(R.id.card4);
                CardView cv55 = (CardView) getView().findViewById(R.id.card5);
                ImageView i15 = (ImageView) getView().findViewById(R.id.WalterLibraryImage);
                i15.setVisibility(View.VISIBLE);
                cv15.setVisibility(View.INVISIBLE);
                cv25.setVisibility(View.INVISIBLE);
                cv35.setVisibility(View.INVISIBLE);
                cv45.setVisibility(View.INVISIBLE);
                cv55.setVisibility(View.INVISIBLE);
                break;
            case R.id.WalkingBridgeImage:
                CardView cv16 = (CardView) getView().findViewById(R.id.card);
                CardView cv26 = (CardView) getView().findViewById(R.id.card2);
                CardView cv36 = (CardView) getView().findViewById(R.id.card3);
                CardView cv46 = (CardView) getView().findViewById(R.id.card4);
                CardView cv56 = (CardView) getView().findViewById(R.id.card5);
                ImageView i16 = (ImageView) getView().findViewById(R.id.WalkingBridgeImage);
                i16.setVisibility(View.INVISIBLE);
                if(spinnerView.equals("All Places"))
                {
                    cv16.setVisibility(View.VISIBLE);
                    cv26.setVisibility(View.VISIBLE);
                    cv36.setVisibility(View.VISIBLE);
                    cv46.setVisibility(View.VISIBLE);
                    cv56.setVisibility(View.VISIBLE);
                }
                else if(spinnerView.equals("Good Views"))
                {
                    cv16.setVisibility(View.VISIBLE);
                    cv26.setVisibility(View.VISIBLE);
                    cv36.setVisibility(View.VISIBLE);
                }
            case R.id.BikePathImage:
                CardView cv17 = (CardView) getView().findViewById(R.id.card);
                CardView cv27 = (CardView) getView().findViewById(R.id.card2);
                CardView cv37 = (CardView) getView().findViewById(R.id.card3);
                CardView cv47 = (CardView) getView().findViewById(R.id.card4);
                CardView cv57 = (CardView) getView().findViewById(R.id.card5);
                ImageView i17 = (ImageView) getView().findViewById(R.id.BikePathImage);
                i17.setVisibility(View.INVISIBLE);
                if(spinnerView.equals("All Places"))
                {
                    cv17.setVisibility(View.VISIBLE);
                    cv27.setVisibility(View.VISIBLE);
                    cv37.setVisibility(View.VISIBLE);
                    cv47.setVisibility(View.VISIBLE);
                    cv57.setVisibility(View.VISIBLE);
                }
                else if(spinnerView.equals("Good Views"))
                {
                    cv17.setVisibility(View.VISIBLE);
                    cv27.setVisibility(View.VISIBLE);
                    cv37.setVisibility(View.VISIBLE);
                }

            case R.id.BigFieldImage:
                CardView cv18 = (CardView) getView().findViewById(R.id.card);
                CardView cv28 = (CardView) getView().findViewById(R.id.card2);
                CardView cv38 = (CardView) getView().findViewById(R.id.card3);
                CardView cv48 = (CardView) getView().findViewById(R.id.card4);
                CardView cv58 = (CardView) getView().findViewById(R.id.card5);
                ImageView i18 = (ImageView) getView().findViewById(R.id.BigFieldImage);
                i18.setVisibility(View.INVISIBLE);
                if(spinnerView.equals("All Places"))
                {
                    cv18.setVisibility(View.VISIBLE);
                    cv28.setVisibility(View.VISIBLE);
                    cv38.setVisibility(View.VISIBLE);
                    cv48.setVisibility(View.VISIBLE);
                    cv58.setVisibility(View.VISIBLE);
                }
                else if(spinnerView.equals("Good Views"))
                {
                    cv18.setVisibility(View.VISIBLE);
                    cv28.setVisibility(View.VISIBLE);
                    cv38.setVisibility(View.VISIBLE);
                }

            case R.id.WalterLibraryImage:
                CardView cv19 = (CardView) getView().findViewById(R.id.card);
                CardView cv29 = (CardView) getView().findViewById(R.id.card2);
                CardView cv39 = (CardView) getView().findViewById(R.id.card3);
                CardView cv49 = (CardView) getView().findViewById(R.id.card4);
                CardView cv59 = (CardView) getView().findViewById(R.id.card5);
                ImageView i19 = (ImageView) getView().findViewById(R.id.WalterLibraryImage);
                i19.setVisibility(View.INVISIBLE);
                if(spinnerView.equals("All Places"))
                {
                    cv19.setVisibility(View.VISIBLE);
                    cv29.setVisibility(View.VISIBLE);
                    cv39.setVisibility(View.VISIBLE);
                    cv49.setVisibility(View.VISIBLE);
                    cv59.setVisibility(View.VISIBLE);
                }
                else if(spinnerView.equals("Useful Places"))
                {
                    cv49.setVisibility(View.VISIBLE);
                }
            case R.id.BohemianFlatsImage:
                CardView cv10 = (CardView) getView().findViewById(R.id.card);
                CardView cv20 = (CardView) getView().findViewById(R.id.card2);
                CardView cv30 = (CardView) getView().findViewById(R.id.card3);
                CardView cv40 = (CardView) getView().findViewById(R.id.card4);
                CardView cv50 = (CardView) getView().findViewById(R.id.card5);
                ImageView i10 = (ImageView) getView().findViewById(R.id.BohemianFlatsImage);
                i10.setVisibility(View.INVISIBLE);
                if(spinnerView.equals("All Places"))
                {
                    cv10.setVisibility(View.VISIBLE);
                    cv20.setVisibility(View.VISIBLE);
                    cv30.setVisibility(View.VISIBLE);
                    cv40.setVisibility(View.VISIBLE);
                    cv50.setVisibility(View.VISIBLE);
                }
                else if(spinnerView.equals("Quiet Spots"))
                {
                    cv50.setVisibility(View.VISIBLE);
                }
            default:
                break;
        }
    }

}