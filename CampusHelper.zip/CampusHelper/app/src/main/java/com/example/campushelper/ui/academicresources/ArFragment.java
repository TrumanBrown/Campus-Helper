package com.example.campushelper.ui.academicresources;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.campushelper.R;
import com.example.campushelper.databinding.FragmentArBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class ArFragment extends Fragment implements View.OnClickListener {

    private FragmentArBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View v = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_ar, null);

        // Initialize buttons and set up click listeners
        Button rmpButton = (Button) v.findViewById(R.id.rmp_button);         // Rate My Professors
        rmpButton.setOnClickListener(this);
        Button ggButton = (Button) v.findViewById(R.id.gg_button);           // GopherGrades
        ggButton.setOnClickListener(this);
        Button housingButton = (Button) v.findViewById(R.id.housing_button); // housing search
        housingButton.setOnClickListener(this);
        Button schedulingButton = (Button) v.findViewById(R.id.scheduling_button); // course scheduling
        schedulingButton.setOnClickListener(this);
        Button writingButton = (Button) v.findViewById(R.id.writing_button); // academic writing center
        writingButton.setOnClickListener(this);
        Button healthButton = (Button) v.findViewById(R.id.health_button);   // mental health resources
        healthButton.setOnClickListener(this);
        FloatingActionButton arHelpButton = v.findViewById(R.id.ar_help_button);   // help
        arHelpButton.setOnClickListener(this);


        // Create the popup window
        View popupView = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_ar_popup, null);

        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        popupWindow.setElevation(90);
        popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);

        // Dismiss the popup window when screen is tapped
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                popupWindow.dismiss();
                return true;
            }
        });


        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // Use cases to determine what to do for each click of a button
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            // Go to Rate My Professor
            case R.id.rmp_button:
                Intent rmp = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ratemyprofessors.com/campusRatings.jsp?sid=1257"));
                startActivity(rmp);
                break;
            // Go to Gopher Grades
            case R.id.gg_button:
                Intent gg = new Intent(Intent.ACTION_VIEW, Uri.parse("https://gophergrades.com"));
                startActivity(gg);
                break;
            // Go to the housing search
            case R.id.housing_button:
                Intent housing = new Intent(Intent.ACTION_VIEW, Uri.parse("https://listings.umn.edu/listing"));
                startActivity(housing);
                break;
            // Go to the course scheduling page
            case R.id.scheduling_button:
                Navigation.findNavController(view).navigate(R.id.nav_ar_scheduling);
                break;
            // Go to the academic writing center page
            case R.id.writing_button:
                Navigation.findNavController(view).navigate(R.id.nav_ar_writing);
                break;
            // Go to the mental health resources page
            case R.id.health_button:
                Navigation.findNavController(view).navigate(R.id.nav_ar_health);
                break;

            case R.id.ar_help_button:
                // Create the popup window
                View popupView = LayoutInflater.from(getActivity()).inflate(
                        R.layout.fragment_ar_popup, null);

                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                boolean focusable = true; // lets taps outside the popup also dismiss it
                PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
                popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                popupWindow.setElevation(90);
                popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

                // Dismiss the popup window when screen is tapped
                popupView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        popupWindow.dismiss();
                        return true;
                    }
                });
                break;
            default:
                break;
        }
    }
}