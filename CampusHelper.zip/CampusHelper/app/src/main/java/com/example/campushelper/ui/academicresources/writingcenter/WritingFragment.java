package com.example.campushelper.ui.academicresources.writingcenter;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.campushelper.R;
import com.example.campushelper.databinding.FragmentArWritingBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class WritingFragment extends Fragment implements View.OnClickListener {

    private FragmentArWritingBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        WritingViewModel writingViewModel =
                new ViewModelProvider(this).get(WritingViewModel.class);

        binding = FragmentArWritingBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        View v = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_ar_writing, null);


        // Initialize buttons and set up click listeners
        Button owmButton = (Button) v.findViewById(R.id.owm_button); // online writing materials
        owmButton.setOnClickListener(this);
        Button poButton = (Button) v.findViewById(R.id.po_button);   // Purdue Owl writing guide
        poButton.setOnClickListener(this);
        Button acButton = (Button) v.findViewById(R.id.ac_button);   // assignment calculator
        acButton.setOnClickListener(this);
        Button rrButton = (Button) v.findViewById(R.id.rr_button);   // research resources
        rrButton.setOnClickListener(this);
        Button wcButton = (Button) v.findViewById(R.id.wc_button);   // schedule a writing consultation
        wcButton.setOnClickListener(this);
        FloatingActionButton wcHelpButton = v.findViewById(R.id.writing_help_button);   // help
        wcHelpButton.setOnClickListener(this);

        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // Use cases to determine what to do for each click of a button
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            // Go to the online writing materials
            case R.id.owm_button:
                Intent owm = new Intent(Intent.ACTION_VIEW, Uri.parse("http://writing.umn.edu/sws/quickhelp/index.html"));
                startActivity(owm);
                break;
            // Go to the Purdue Owl's writing guide
            case R.id.po_button:
                Intent po = new Intent(Intent.ACTION_VIEW, Uri.parse("https://owl.purdue.edu/owl/purdue_owl.html"));
                startActivity(po);
                break;
            // Go to assignment calculator
            case R.id.ac_button:
                Intent ac = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.lib.umn.edu/services/ac"));
                startActivity(ac);
                break;
            // Got to research resources
            case R.id.rr_button:
                Intent rr = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.lib.umn.edu/services/prc"));
                startActivity(rr);
                break;
            // Go schedule a writing consultation appointment
            case R.id.wc_button:
                Intent wc = new Intent(Intent.ACTION_VIEW, Uri.parse("http://writing.umn.edu/sws/visit/index.html"));
                startActivity(wc);
                break;
            case R.id.writing_help_button:
                // Create the popup window
                View popupView = LayoutInflater.from(getActivity()).inflate(
                        R.layout.fragment_ar_popup, null);

                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                boolean focusable = true; // lets taps outside the popup also dismiss it
                PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
                popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                popupWindow.setElevation(90);
                popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

                // Dismiss the popup window when screen is tapped
                popupView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        popupWindow.dismiss();
                        return true;
                    }
                });
                break;
            default:
                break;
        }
    }
}
