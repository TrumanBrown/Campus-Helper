package com.example.campushelper.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.campushelper.R;
import com.example.campushelper.databinding.FragmentHomeBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class HomeFragment extends Fragment implements View.OnClickListener {

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View v = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_home, null);

        // Initialize buttons and set up click listeners
        Button rfButton = (Button) v.findViewById(R.id.rf_button);      // Route Finder
        rfButton.setOnClickListener(this);
        Button lfButton = (Button) v.findViewById(R.id.lf_button);      // Location Finder
        lfButton.setOnClickListener(this);
        Button arButton = (Button) v.findViewById(R.id.ar_button);      // Academic Resources
        arButton.setOnClickListener(this);

        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // Use cases to determine what to do for each click of a button
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            // Go to the route finder page
            case R.id.rf_button:
                Navigation.findNavController(view).navigate(R.id.nav_rf);
                break;
            // Go to the location page
            case R.id.lf_button:
                Navigation.findNavController(view).navigate(R.id.nav_lf);
                break;
            // Go to the academic resources page
            case R.id.ar_button:
                Navigation.findNavController(view).navigate(R.id.nav_ar);
                break;
            default:
                break;
        }
    }
}