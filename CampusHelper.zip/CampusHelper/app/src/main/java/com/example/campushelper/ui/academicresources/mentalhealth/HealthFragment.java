package com.example.campushelper.ui.academicresources.mentalhealth;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.campushelper.R;
import com.example.campushelper.databinding.FragmentArHealthBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class HealthFragment extends Fragment implements View.OnClickListener {

    private FragmentArHealthBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HealthViewModel healthViewModel =
                new ViewModelProvider(this).get(HealthViewModel.class);

        binding = FragmentArHealthBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        View v = LayoutInflater.from(getActivity()).inflate(
                R.layout.fragment_ar_health, null);


        // Initialize buttons and set up click listeners
        Button stmButton = (Button) v.findViewById(R.id.stm_button); // stress management
        stmButton.setOnClickListener(this);
        Button daButton = (Button) v.findViewById(R.id.da_button);   // drug and alcohol misuse
        daButton.setOnClickListener(this);
        Button smButton = (Button) v.findViewById(R.id.sm_button);   // sexual misconduct
        smButton.setOnClickListener(this);
        Button youButton = (Button) v.findViewById(R.id.you_button);   // YOU at UMN
        youButton.setOnClickListener(this);
        Button apptButton = (Button) v.findViewById(R.id.appt_button);   // schedule an appointment
        apptButton.setOnClickListener(this);
        FloatingActionButton healthHelpButton = v.findViewById(R.id.health_help_button);   // help
        healthHelpButton.setOnClickListener(this);

        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // Use cases to determine what to do for each click of a button
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            // Go to stress management
            case R.id.stm_button:
                Intent stm = new Intent(Intent.ACTION_VIEW, Uri.parse("https://extension.umn.edu/mental-well-being/stress-and-change#managing-change-554311"));
                startActivity(stm);
                break;
            // Go to drug and alcohol misuse
            case R.id.da_button:
                Intent da = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ri.umn.edu/alcohol-and-college-life.html"));
                startActivity(da);
                break;
            // Go to sexual misconduct
            case R.id.sm_button:
                Intent sm = new Intent(Intent.ACTION_VIEW, Uri.parse("https://safe-campus.umn.edu/sexual-misconduct-prevention"));
                startActivity(sm);
                break;
            // Go to YOU at UMN
            case R.id.you_button:
                Intent you = new Intent(Intent.ACTION_VIEW, Uri.parse("https://you.umn.edu/"));
                startActivity(you);
                break;
            // Go schedule an appointment
            case R.id.appt_button:
                Intent appt = new Intent(Intent.ACTION_VIEW, Uri.parse("https://counseling.umn.edu/getting-started"));
                startActivity(appt);
                break;
            case R.id.health_help_button:
                // Create the popup window
                View popupView = LayoutInflater.from(getActivity()).inflate(
                        R.layout.fragment_ar_popup, null);

                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                boolean focusable = true; // lets taps outside the popup also dismiss it
                PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
                popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                popupWindow.setElevation(90);
                popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

                // Dismiss the popup window when screen is tapped
                popupView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        popupWindow.dismiss();
                        return true;
                    }
                });
                break;
            default:
                break;
        }
    }
}
